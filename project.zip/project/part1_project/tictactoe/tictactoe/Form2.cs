﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tictactoe
{
    public partial class Form2 : Form
    {
        Form1 f = new Form1();
        Form3 d = new Form3();
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          f= new Form1();
            if(f == null)
            {
                f.Show();

            }
            else
            {
                f.Show();
                f.Focus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            d = new Form3();
            if (d == null)
            {
                d.Show();

            }
            else
            {
                d.Show();
                d.Focus();
            }
        }
    }
}
